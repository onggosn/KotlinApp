package com.example.footballapp.view.matchlist

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.support.v7.widget.SearchView
import android.widget.Toast
import com.example.footballapp.R
import com.example.footballapp.model.League.LeagueDesc
import com.example.footballapp.model.matchdetail.MatchDetail
import com.example.footballapp.model.matchlist.NextMatch
import com.example.footballapp.model.matchlist.PrevMatch
import com.example.footballapp.model.teamdetail.Team
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.presenter.PrevMatchPresenter
import com.example.footballapp.utils.invisible
import com.example.footballapp.utils.visible
import com.example.footballapp.view.MainView
import com.example.footballapp.view.matchdetail.MatchDetailView
import com.google.gson.Gson
import kotlinx.android.synthetic.main.frag_prevmatch.*
import org.jetbrains.anko.support.v4.onRefresh

class FragPrevmatch : Fragment(), MainView {
    private var match: MutableList<PrevMatch> = mutableListOf()
    private lateinit var adapter: PrevMatchAdapter
    private lateinit var presenter: PrevMatchPresenter
    private lateinit var idLeague: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val idLeague = arguments?.getString("id")
        this.idLeague = idLeague.toString()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.frag_prevmatch, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val request = ApiRepository()
        val gson = Gson()
        presenter = PrevMatchPresenter(this, request, gson)
        presenter.getPrevMatch(idLeague)

        adapter = PrevMatchAdapter(match){
            partItem: PrevMatch -> sendMatchId(partItem)
        }

        fragPrevMatch.adapter = adapter
        fragPrevMatch.layoutManager = LinearLayoutManager(this.context)

        searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                presenter.getEvent(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText == ""){
                    presenter.getPrevMatch(idLeague)
                }
                return true
            }
        })

        swipeRefresh.onRefresh {
            presenter.getPrevMatch(idLeague)
        }
    }

    override fun showLoading() {
        viewprogressBar.visible()
    }

    override fun hideLoading() {
        viewprogressBar.invisible()
    }

    override fun showPrevMatch(data: List<PrevMatch>) {
        swipeRefresh.isRefreshing = false
        match.clear()
        match.addAll(data)
        adapter.notifyDataSetChanged()
    }

    override fun notFound() {
        Toast.makeText(this.context, "Data Not Found!", Toast.LENGTH_SHORT).show()
    }

    companion object {
        fun newInstance(idLeague: String): FragPrevmatch {
            val args = Bundle()
            args.putString("id", idLeague)
            val fragment = FragPrevmatch()
            fragment.arguments = args
            return fragment
        }
    }

    private fun sendMatchId(matchId: PrevMatch){
        val intent = Intent(this.context, MatchDetailView::class.java)
        intent.putExtra("MATCHID", matchId.eventId.toString())
        startActivity(intent)
    }

    override fun showLeagueDesc(data: LeagueDesc) {}
    override fun showNextMatch(data: List<NextMatch>) {}
    override fun showMatchDetail(data: MatchDetail) {}
    override fun showBadge(dataHome: Team, dataAway: Team) {}
}