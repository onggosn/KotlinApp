package com.example.footballapp.presenter

import com.example.footballapp.model.League.LeagueDescResponse
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.netservices.TheSportDBApi
import com.example.footballapp.view.MainView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class LeagueDescPresenter(
    private val view: MainView,
    private val apiRepository: ApiRepository,
    private val gson: Gson) {

    fun getLeagueDesc(leagueId: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getLeagueDesc(leagueId)),
                LeagueDescResponse::class.java)

            uiThread {
                view.showLeagueDesc(data.leagues[0])
                view.hideLoading()
            }
        }
    }
}