package com.example.footballapp.model.teamdetail

import com.google.gson.annotations.SerializedName

data class Team(
    @SerializedName("strTeamBadge")
    var strTeamBadge: String? = null,

    @SerializedName("strTime")
    var eventTime: String? = null,

    @SerializedName("dateEvent")
    var eventDate: String? = null
)