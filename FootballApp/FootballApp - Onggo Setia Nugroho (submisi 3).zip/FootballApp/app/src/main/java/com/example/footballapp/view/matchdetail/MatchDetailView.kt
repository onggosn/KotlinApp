package com.example.footballapp.view.matchdetail

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.footballapp.R
import com.example.footballapp.model.League.LeagueDesc
import com.example.footballapp.model.matchdetail.MatchDetail
import com.example.footballapp.model.matchlist.NextMatch
import com.example.footballapp.model.matchlist.PrevMatch
import com.example.footballapp.model.teamdetail.Team
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.presenter.MatchDetailPresenter
import com.example.footballapp.presenter.TeamPresenter
import com.example.footballapp.utils.dateFormat
import com.example.footballapp.utils.invisible
import com.example.footballapp.utils.visible
import com.example.footballapp.view.MainView
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.match_detail.*
import org.jetbrains.anko.support.v4.onRefresh

class MatchDetailView : AppCompatActivity(), MainView {
    lateinit var presenter: MatchDetailPresenter
    lateinit var presenterTeam: TeamPresenter
    lateinit var teamIdHome: String
    lateinit var teamIdAway: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.match_detail)

        val request = ApiRepository()
        val gson = Gson()
        val oMatch = intent.getStringExtra("MATCHID")
        presenter = MatchDetailPresenter(this, request, gson)
        presenter.getMatchDetail(oMatch)

        swipRefreshMatchDetail.onRefresh {
            presenter.getMatchDetail(oMatch)
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun showLoading() {
        progressBar.visible()
    }

    override fun hideLoading() {
        progressBar.invisible()
    }

    override fun showMatchDetail(data: MatchDetail) {
        swipRefreshMatchDetail.isRefreshing = false
        teamIdHome = data.idHome.toString()
        teamIdAway = data.idAway.toString()

        val request = ApiRepository()
        val gson = Gson()

        presenterTeam = TeamPresenter(this, request, gson)
        presenterTeam.getBadge(teamIdHome, teamIdAway)

        tvEventDate.text = dateFormat("${data.dateMatch} ${data.stringTime}")
        tvHomeTeam.text = data.homeName
        tvHomeScore.text = data.homeScore.toString()
        tvAwayTeam.text = data.awayName
        tvAwayScore.text = data.awayScore.toString()
        tvHomeGoals.text = data.homeGoalScorer?.replace(";", "\n")
        tvAwayGoals.text = data.awayGoalScorer?.replace(";", "\n")
        tvYellowHome.text = data.homeYellowCards?.replace(";", "\n")
        tvYellowAway.text = data.awayYellowCards?.replace(";", "\n")
        tvRedHome.text = data.homeRedCards?:"-"
        tvRedAway.text = data.awayRedCards?:"-"
        tvHomeKeeper.text = data.homeGoalKeeper?.replace(";", "\n")
        tvAwayKeeper.text = data.awayGoalKeeper?.replace(";", "\n")
        tvHomeDef.text = data.homeDefense?.replace(";", "\n")
        tvAwayDef.text = data.awayDefense?.replace(";", "\n")
        tvHomeMid.text = data.homeMidfield?.replace(";", "\n")
        tvAwayMid.text = data.awayMidfield?.replace(";", "\n")
        tvHomeFw.text = data.homeForward?.replace(";", "\n")
        tvAwayFw.text = data.awayForward?.replace(";", "\n")
        tvHomeSub.text = data.homeSubtitute?.replace(";", "\n")
        tvAwaySub.text = data.awaySubtitute?.replace(";", "\n")

        supportActionBar?.title = data.eventName
    }

    override fun showBadge(dataHome: Team, dataAway: Team){
        Picasso.get().load("${dataHome.strTeamBadge}/preview").into(imgHomeTeam)
        Picasso.get().load("${dataAway.strTeamBadge}/preview").into(imgAwayTeam)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun showLeagueDesc(data: LeagueDesc) {}
    override fun showPrevMatch(data: List<PrevMatch>) {}
    override fun showNextMatch(data: List<NextMatch>) {}
    override fun notFound() {}
}