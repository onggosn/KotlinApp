package com.example.footballapp.presenter

import com.example.footballapp.model.teamdetail.TeamResponse
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.netservices.TheSportDBApi
import com.example.footballapp.view.MainView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class TeamPresenter (
    private val view: MainView,
    private val apiRepository: ApiRepository,
    private val gson: Gson
){

    fun getBadge(homeId: String?, awayId: String?) {
        doAsync {
            val dataHome = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getBadge(homeId)),
                TeamResponse::class.java)
            val dataAway= gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getBadge(awayId)),
                TeamResponse::class.java)
            uiThread {
                view.showBadge(dataHome.teams[0], dataAway.teams[0])
                view.hideLoading()
            }
        }
    }
}