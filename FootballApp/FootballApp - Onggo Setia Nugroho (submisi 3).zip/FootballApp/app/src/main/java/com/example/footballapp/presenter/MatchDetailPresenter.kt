package com.example.footballapp.presenter

import com.example.footballapp.model.matchdetail.MatchDetailResponse
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.netservices.TheSportDBApi
import com.example.footballapp.view.MainView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class MatchDetailPresenter (
    private val view: MainView,
    private val apiRepository: ApiRepository,
    private val gson: Gson
){

    fun getMatchDetail(eventId: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getMatchDetail(eventId)),
                MatchDetailResponse::class.java)
            uiThread {
                //view.hideLoading()
                view.showMatchDetail(data.events[0])
            }
        }
    }
}