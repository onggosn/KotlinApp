package com.example.footballapp.model.teamdetail

data class TeamResponse (
    val teams: List<Team>
)