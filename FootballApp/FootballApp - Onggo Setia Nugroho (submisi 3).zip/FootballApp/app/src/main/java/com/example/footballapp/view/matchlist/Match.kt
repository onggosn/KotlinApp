package com.example.footballapp.view.matchlist

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.footballapp.R
import com.example.footballapp.model.League.League
import kotlinx.android.synthetic.main.activity_match.*

class Match : AppCompatActivity() {
    lateinit var leagueId: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match)

        initToolbar()

        val oLeague = intent.getParcelableExtra<League>("LEAGUEID")
        leagueId = oLeague.leagueID.toString()

        val fragmentAdapter = MatchAdapter(supportFragmentManager, leagueId)
        view_pager.adapter = fragmentAdapter
        tab_layout.setupWithViewPager(view_pager)
    }

    private fun initToolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar_title.text = "MATCH LIST"
        supportActionBar?.title = ""
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}