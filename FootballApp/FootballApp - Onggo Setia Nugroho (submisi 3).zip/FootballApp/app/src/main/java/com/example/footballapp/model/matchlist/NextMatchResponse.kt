package com.example.footballapp.model.matchlist

data class NextMatchResponse(
    val events: List<NextMatch>
)