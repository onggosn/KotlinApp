package com.example.footballapp.model.League

data class LeagueDescResponse(
    val leagues: List<LeagueDesc>
)