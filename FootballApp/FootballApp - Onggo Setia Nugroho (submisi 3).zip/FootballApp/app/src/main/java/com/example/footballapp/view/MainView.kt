package com.example.footballapp.view

import com.example.footballapp.model.League.LeagueDesc
import com.example.footballapp.model.matchdetail.MatchDetail
import com.example.footballapp.model.matchlist.NextMatch
import com.example.footballapp.model.matchlist.PrevMatch
import com.example.footballapp.model.teamdetail.Team

interface MainView{
    fun showLoading()
    fun hideLoading()
    fun showLeagueDesc(data: LeagueDesc)
    fun showPrevMatch(data: List<PrevMatch>)
    fun showNextMatch(data: List<NextMatch>)
    fun showMatchDetail(data: MatchDetail)
    fun showBadge(dataHome: Team, dataAway: Team)
    fun notFound()
}