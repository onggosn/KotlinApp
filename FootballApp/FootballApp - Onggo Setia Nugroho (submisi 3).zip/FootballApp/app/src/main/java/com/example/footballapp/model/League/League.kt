package com.example.footballapp.model.League

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize //kotlin android extensions parcelize
data class League (var leagueID: String? = "", var leagueName: String? = "", var badges: String? = "", var description: String? = "" ) : Parcelable