package com.example.footballapp.model.matchlist

data class PrevMatchResponse(
    val events: List<PrevMatch>,
    val event: List<PrevMatch>
)