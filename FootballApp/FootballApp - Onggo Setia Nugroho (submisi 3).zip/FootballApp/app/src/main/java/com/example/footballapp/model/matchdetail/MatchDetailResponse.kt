package com.example.footballapp.model.matchdetail

data class MatchDetailResponse(
    val events: List<MatchDetail>
)