package com.example.footballapp.presenter

import com.example.footballapp.model.matchlist.PrevMatchResponse
import com.example.footballapp.netservices.ApiRepository
import com.example.footballapp.netservices.TheSportDBApi
import com.example.footballapp.view.MainView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class PrevMatchPresenter (
    private val view: MainView,
    private val apiRepository: ApiRepository,
    private val gson: Gson ){

    fun getPrevMatch(leagueId: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getPrevMatch(leagueId)),
                PrevMatchResponse::class.java)
            uiThread {
                view.hideLoading()
                view.showPrevMatch(data.events)
            }
        }
    }

    fun getEvent(eventName: CharSequence?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getEvent(eventName)),
                PrevMatchResponse::class.java)
            uiThread {
                view.hideLoading()
                if (data.event != null) {
                    view.showPrevMatch(data.event)
                }else{
                    view.notFound()
                }
            }
        }
    }
}